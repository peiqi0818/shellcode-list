#!/bin/bash

nasm -f elf64 -g hello_world.asm -o hello_world.o
ld hello_world.o -o hello_world
./hello_world